import { configureStore } from "@reduxjs/toolkit";
import { persistStore, persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";
import authReducer from "./slices/authSlice";
import movieReducer from "./slices/movieSlice";
import { combineReducers } from "@reduxjs/toolkit";
import { thunk } from "redux-thunk";

// menggabungkan semua reducer menjadi satu fungsi root reducer
const rootReducer = combineReducers({ auth: authReducer, movie: movieReducer });

// konfigurasi untuk persistReducer
const persistConfig = {
  key: "root",
  storage,
  blacklist: ["movie"],
};

// menggunakan redux-persist untuk membuat store yang tersimpan di localstorage
const persistedReducer = persistReducer(persistConfig, rootReducer);

// konfigurasi redux store
export const store = configureStore({
  reducer: persistedReducer,
  devTools: import.meta.env.MODE === "development",
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }).concat(thunk),
});
// export persistor
export const persistor = persistStore(store);
