import { createSlice } from "@reduxjs/toolkit";

// state inisialisasi
const initialState = {
  token: null,
  userInfo: null,
};

// definisi slice auth
const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setToken(state, action) {
      state.token = action.payload;
    },
    setUserInfo(state, action) {
      state.userInfo = action.payload;
    },
  },
});

export const { setToken, setUserInfo } = authSlice.actions;
export default authSlice.reducer;
