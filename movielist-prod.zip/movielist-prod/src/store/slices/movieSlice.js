import { createSlice } from "@reduxjs/toolkit";

// state inisialisasi
const initialState = {
  movies: [],
  genres: [],
  movieDetails: null,
  rated: [],
  pagination: null,
  paginationMovies: null,
};

// definisi slice movie
const movieSlice = createSlice({
  name: "movie",
  initialState,
  reducers: {
    setMovies(state, action) {
      state.movies = action.payload;
    },
    setGenres(state, action) {
      state.genres = action.payload;
    },
    setMovieDetails(state, action) {
      state.movieDetails = action.payload;
    },
    setTopRatedMovies(state, action) {
      state.rated = action.payload;
    },
    setPagination(state, action) {
      state.pagination = action.payload;
    },
    setPaginationMovies(state, action) {
      state.paginationMovies = action.payload;
    },
  },
});

export const {
  setMovies,
  setGenres,
  setMovieDetails,
  setTopRatedMovies,
  setPagination,
  setPaginationMovies,
} = movieSlice.actions;
export default movieSlice.reducer;
