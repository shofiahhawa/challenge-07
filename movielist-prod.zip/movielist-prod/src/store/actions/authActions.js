import axios from "axios";
import { setToken, setUserInfo } from "../slices/authSlice";

// fungsi action untuk melakukan login dengan email dan password
export const login =
  ({ email, password }) =>
  async (dispatch) => {
    try {
      const { data } = await axios.post("https://shy-cloud-3319.fly.dev/api/v1/auth/login", {
        email,
        password,
      });

      dispatch(setToken(data.data.token));
    } catch (error) {
      alert(error.response.data.message);
    }
  };

// fungsi action untuk melakukan login oauth
export const googleLogin = (access_token) => async (dispatch) => {
  try {
    // melakukan POST request ke endpoint auth dengan google
    const { data } = await axios.post("https://shy-cloud-3319.fly.dev/api/v1/auth/google", {
      access_token,
    });

    dispatch(setToken(data.data.token));
  } catch (error) {
    alert(error.response.data.message);
  }
};

// fungsi action untuk mengambil info user
export const getUserInfo = () => async (dispatch, getState) => {
  const { token } = getState().auth;
  if (!token) {
    dispatch(setUserInfo(null));
    return;
  }

  try {
    const { data } = await axios.get("https://shy-cloud-3319.fly.dev/api/v1/auth/me", {
      headers: { Authorization: `Bearer ${token}` },
    });

    dispatch(setUserInfo(data.data));
  } catch (error) {
    alert(error.response.data.message);
  }
};

// fungsi untuk melakukan register via nama, email dan password
export const register =
  ({ name, email, password }) =>
  async (dispatch) => {
    try {
      const { data } = await axios.post("https://shy-cloud-3319.fly.dev/api/v1/auth/register", {
        name,
        email,
        password,
      });

      dispatch(setToken(data.data.token));
    } catch (error) {
      alert(error.response.data.message);
    }
  };
