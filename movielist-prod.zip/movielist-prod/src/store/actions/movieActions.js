import axios from "axios";
import {
  setMovies,
  setGenres,
  setMovieDetails,
  setTopRatedMovies,
  setPagination,
  setPaginationMovies,
} from "../slices/movieSlice";

// fungsi action untuk mengambil list movies dari API
export const getMovies = (params) => async (dispatch) => {
  const url = `https://api.themoviedb.org/3/${
    params?.get("query") ? "search" : "discover"
  }/movie?api_key=${import.meta.env.VITE_TMDB_API_KEY}&include_adult=false&${
    params?.toString() ?? ""
  }`;

  try {
    const response = await axios.get(url, { header: { accept: "application/json" } });

    console.log("response data ", response.data);

    dispatch(setMovies(response.data.results));
  } catch (err) {
    alert("Error fetching data: ", err);
  }
};

// fungsi action untuk mengambil list genre dari API
export const getGenres = () => async (dispatch) => {
  try {
    const response = await axios.get(
      `https://api.themoviedb.org/3/genre/movie/list?api_key=${
        import.meta.env.VITE_TMDB_API_KEY
      }&language=en-US`
    );

    dispatch(setGenres(response.data.genres));
  } catch (err) {
    alert("Error fetching genres: ", err);
  }
};

// fungsi action untuk mengambil detail sebuah movie dari API
export const getMovieDetails = (id) => async (dispatch) => {
  try {
    const response = await axios.get(
      `https://api.themoviedb.org/3/movie/${id}?language=en-US&api_key=${
        import.meta.env.VITE_TMDB_API_KEY
      }&append_to_response=credits`,
      { headers: { accept: "application/json" } }
    );

    console.log("response.data ", response.data);
    dispatch(setMovieDetails(response.data));
  } catch (error) {
    alert("Movie not found!");
    console.error("Error fetching data: ", error);
  }
};

// fungsi action untuk mengambil top rated movies dari API
export const getTopRatedMovies = (page) => async (dispatch) => {
  try {
    console.log("page", page);
    const response = await axios.get(
      `https://api.themoviedb.org/3/movie/top_rated?language=en-US&api_key=${
        import.meta.env.VITE_TMDB_API_KEY
      }&page=${page}=&append_to_response=credits`,
      { headers: { accept: "application/json" } }
    );
    const recc = response?.data?.results.slice(0, 12);
    console.log("top rated", response.data);
    dispatch(setTopRatedMovies(recc));
    dispatch(setPagination(response.data));
  } catch (error) {
    // console.error("Error fetching data: ", error);
  }
};
