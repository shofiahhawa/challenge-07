import { useEffect, useState } from "react";
import axios from "axios";
import Slider from "react-slick";
import { PlayCircleIcon } from "lucide-react";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./slick-custom.css";
import { Link } from "react-router-dom";

// type Movie {
//   adult: boolean;
//   backdrop_path: string;
//   genre_ids: number[];
//   id: number;
//   original_language: string;
//   original_title: string;
//   overview: string;
//   popularity: number;
//   poster_path: string;
//   release_date: string;
//   title: string;
//   video: boolean;
//   vote_average: number;
//   vote_count: number;
// }

export default function BannerSlider() {
  const [movies, setMovies] = useState([]);

  useEffect(() => {
    const getBannerMovies = async () => {
      try {
        // memanggil API dan mendapatkan data movie untuk banner
        const response = await axios.get(
          `https://api.themoviedb.org/3/discover/movie?include_adult=false&include_video=false&language=en-US&page=1&sort_by=popularity.desc&api_key=${
            import.meta.env.VITE_TMDB_API_KEY
          }`,
          { header: { accept: "application/json" } }
        );

        // menyimpan 3 buah data movie dari array response ke state movies
        setMovies(response.data.results.slice(0, 3));
      } catch (err) {
        alert("Error fetching banner movies: ", err);
      }
    };

    getBannerMovies();
  }, []);

  return (
    // memakai component Slider dari library react-slick
    <Slider
      dots
      infinite
      speed={500}
      slidesToShow={1}
      autoplay
      arrows={false}
      className="w-full h-full"
    >
      {movies.map((movie, i) => (
        // malkukan perulangan untuk setiap item di array state movies dan tampilkan di component BannerItem
        <BannerItem key={i} {...movie} />
      ))}
    </Slider>
  );
}

// component BannerItem untuk menampilkan item movie di slider
function BannerItem({ backdrop_path, title, overview, id }) {
  // mengambil url gambar backdrop dari API dan digabungkan dengan URL base dari image API
  const imgUrl = `${import.meta.env.VITE_TMDB_IMAGE_URL}${backdrop_path}`;

  const onTrailerClick = async () => {
    try {
      // memanggil API untuk mendapatkan data videos berdasarkan id movie
      const response = await axios.get(
        `https://api.themoviedb.org/3/movie/${id}/videos?api_key=${
          import.meta.env.VITE_TMDB_API_KEY
        }`
      );

      // mencari video trailer dari data response
      const trailer = response.data.results.find((video) => video.type === "Trailer");

      // buka window baru yang menuju trailer movie di youtube
      window.open(`https://www.youtube.com/watch?v=${trailer.key}`, "_blank");
    } catch (e) {
      alert("Error fetching trailer: ", e);
    }
  };

  return (
    <div className="group relative w-full min-h-[80vh] grid content-center bg-black p-5">
      <div
        className="absolute inset-0 opacity-50 group-hover:opacity-65 bg-cover bg-center"
        style={{
          backgroundImage: `url(${imgUrl})`,
        }}
      />
      <div className="z-10 text-white max-w-lg space-y-4">
        <Link to={`/details/${id}`} className="text-6xl font-bold cursor-pointer hover:underline">
          {title}
        </Link>
        <p>{overview}</p>
        <button
          role="link"
          onClick={onTrailerClick}
          className="inline-flex items-center bg-cyan-500 hover:opacity-90 w-max py-3 px-5 rounded-full"
        >
          <PlayCircleIcon className="size-5 mr-2" />
          Watch Trailer
        </button>
      </div>
    </div>
  );
}
