import { SearchIcon } from "lucide-react";

// memindahkan komponen search input ke file terpisah
export default function SearchInput({ value, onChange, transparent = false }) {
  return (
    <div className="flex border-2 border-cyan-500 rounded-full overflow-hidden">
      <input
        id="search"
        type="text"
        placeholder="Search Movie"
        value={value}
        onChange={onChange}
        className={`px-3 py-2 text-sm outline-none inline-block w-96 ${
          // menambahkan style transparan jika prop transparent bernilai true
          transparent ? "text-white placeholder:text-white bg-transparent" : null
        }`}
      />
      <button
        type="submit"
        className="px-3 py-2 bg-cyan-500 text-white text-sm font-semibold inline-block hover:opacity-90"
      >
        <SearchIcon className="size-4" />
        <span className="sr-only">Search</span>
      </button>
    </div>
  );
}
