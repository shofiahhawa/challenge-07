import { Link } from "react-router-dom";
import { ArrowRightIcon } from "lucide-react";

// komponen untuk menampilkan rincian movie dalam bentuk kartu
export default function MovieCard({ id, poster_path, title, release_date, vote_average }) {
  return (
    <div className="flex flex-col gap-y-5 max-w-[400px] min-w-[280px] max-sm:min-w-[250px] shadow-[0_0_2px_1px_rgb(0,0,0,0.3)] rounded-lg items-center justify-between">
      <div className="bg-cover min-h-[250px] w-full rounded-t-md flex flex-col items-center pt-5 relative">
        <img
          className="absolute -z-20 max-h-[250px] object-cover w-full top-0 left-0 filter blur-[3px]"
          src={`https://image.tmdb.org/t/p/w500/${poster_path}`}
          alt=""
        />
        <img
          src={`https://image.tmdb.org/t/p/w500/${poster_path}`}
          alt={title}
          className="max-w-44 rounded-sm"
        />
      </div>
      <div className="flex flex-col items-center px-4">
        <Link
          to={`/details/${id}`}
          className="font-bold text-lg px-5 hover:underline hover:text-cyan-500"
        >
          {title}
        </Link>
        <h3 className="text-zinc-600">{release_date}</h3>
        <span className="px-2 py-1 bg-cyan-500 text-white font-medium rounded-full w-max">
          {vote_average.toFixed(1)}/10
        </span>
      </div>
      <div className="w-full px-4 py-2 flex justify-end">
        <Link
          className="group inline-flex hover:underline hover:text-white hover:bg-cyan-500 py-2 px-5 border-2 border-cyan-500 rounded-full font-semibold"
          to={`/details/${id}`}
        >
          See Details
          <ArrowRightIcon className="ml-2 text-cyan-500 group-hover:text-white" />
        </Link>
      </div>
    </div>
  );
}
