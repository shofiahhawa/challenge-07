import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Link } from "react-router-dom";
import { useEffect } from "react";
import { LogOutIcon } from "lucide-react";
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import SearchInput from "../SearchInput";
import { getUserInfo } from "../../store/actions/authActions";
import { setToken } from "../../store/slices/authSlice";

// komponen navigation yang berada di paling atas page
export default function Navigation({ variant = "default" }) {
  const [query, setQuery] = useState("");
  // memakai hook useNavigate untuk navigasi ke halaman lain
  const navigate = useNavigate();

  const dispatch = useDispatch();
  const { token, userInfo } = useSelector((state) => state.auth);

  const logout = () => {
    dispatch(setToken(null));
  };

  const onQueryChange = (event) => {
    setQuery(event.target.value);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (!query || query.trim().length === 0) return alert("Mohon inputkan movie");

    // navigasi ke halaman movies dengan query parameter q sebagai penampung value pencarian
    navigate(`/movies?query=${query}`);
  };

  useEffect(() => {
    // melakukan dispatch untuk mengambil info user
    dispatch(getUserInfo());
  }, [dispatch, token]);

  // variant khusus untuk halaman banner
  if (variant === "banner") {
    return (
      <nav className="z-10 absolute top-0 w-full flex flex-wrap justify-between py-4 px-5">
        <h1 className="flex text-3xl font-extrabold text-cyan-500">Movie List</h1>
        <form onSubmit={handleSubmit} className="place-content-center flex">
          <SearchInput transparent value={query} onChange={onQueryChange} />
        </form>
        <div className="flex items-center h-full text-white border-2 border-cyan-500 rounded-full overflow-hidden">
          {userInfo !== null && <p className="px-5">Welcome, {userInfo.name}!</p>}
          <button
            className="px-5 py-1 h-full text-cyan-500 hover:opacity-90"
            onClick={() => logout()}
          >
            <LogOutIcon className="size-5" />
            <span className="sr-only">Logout</span>
          </button>
        </div>
      </nav>
    );
  }

  // variant default untuk halaman lain
  return (
    <nav className="bg-cyan-500 w-full flex flex-wrap justify-between py-4 px-5">
      <h2 className="flex text-3xl font-extrabold text-white">
        <Link to="/">Movie List</Link>
      </h2>
      <div className="flex items-center h-full text-white border-2 border-white rounded-full overflow-hidden">
        {userInfo !== null && <p className="px-5">Welcome, {userInfo.name}!</p>}
        <button
          className="px-5 py-1 h-full bg-white text-cyan-500 hover:opacity-90"
          onClick={() => logout()}
        >
          <LogOutIcon className="size-5" />
          <span className="sr-only">Logout</span>
        </button>
      </div>
    </nav>
  );
}
