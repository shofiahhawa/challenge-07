import { useEffect } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowLeftIcon } from "lucide-react";
import { useSelector, useDispatch } from "react-redux";
import Navigation from "../components/layout/Navigation";
import { getMovieDetails } from "../store/actions/movieActions";

export default function DetailsPage() {
  const { movieDetails } = useSelector((state) => state.movie);
  // mengambil id dari parameter URL melalui hook useParams
  const { id } = useParams();

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getMovieDetails(id));
  }, [dispatch, id]);

  return (
    <>
      <Navigation />
      <main className="container mx-auto mt-4 space-y-4">
        <div className="flex gap-4 items-center">
          <Link to={-1}>
            <ArrowLeftIcon className="size-7 text-cyan-500" />
          </Link>
          <h1 className="text-3xl font-semibold">Movie Details</h1>
        </div>
        {/* menampilkan detail movie jika data sudah ada */}
        {movieDetails !== null && (
          <div className="relative w-full h-full flex flex-col lg:flex-row gap-10 bg-white">
            {/* menjadikan gambar backdrop sebagai background */}
            <div
              className="absolute w-full h-full top-0 bg-center bg-cover opacity-15"
              style={{
                backgroundImage: `url(${import.meta.env.VITE_TMDB_IMAGE_URL}${
                  movieDetails.backdrop_path
                })`,
              }}
            />
            <img
              src={`${import.meta.env.VITE_TMDB_IMAGE_URL}${movieDetails.poster_path}`}
              alt={movieDetails.title}
              className="w-96 shrink-0 border-8 border-cyan-500 z-10"
            />
            {/* informasi detail movie */}
            <div className="space-y-4 z-10 py-4 pr-10">
              <div className="flex items-center gap-4">
                <h2 className="text-2xl text-cyan-500 font-bold">{movieDetails.title}</h2>
                <span className="px-2 py-1 bg-cyan-500 text-white font-medium rounded-full">
                  {movieDetails.vote_average.toFixed(1)}/10
                </span>
              </div>
              <p className="text-sm text-gray-500">Release: {movieDetails.release_date}</p>
              <div className="font-medium inline-flex items-center gap-2">
                <span>Genres:</span>
                {movieDetails.genres.map((genre) => (
                  <span
                    key={genre.id}
                    className="px-2 py-1 text-sm text-white bg-zinc-500 rounded-full"
                  >
                    {genre.name}
                  </span>
                ))}
              </div>
              <p>
                <span className="font-medium">Writers</span>:{" "}
                {movieDetails.credits.crew
                  .filter((crew) => crew.job === "Writer" || crew.job === "Screenplay")
                  .map((crew) => crew.name)
                  .join(", ")}
              </p>
              <p>
                <span className="font-medium">Actors</span>:{" "}
                {movieDetails.credits.cast
                  .slice(0, 3)
                  .map((actor) => actor.name)
                  .join(", ")}
              </p>
              <p>
                <span className="font-medium">Description</span>: {movieDetails.overview}
              </p>
              <p className="text-cyan-500 font-medium">
                <span>Languages</span>:{" "}
                {movieDetails.spoken_languages.map((lang) => lang.english_name).join(", ")}
              </p>
            </div>
          </div>
        )}
      </main>
    </>
  );
}
