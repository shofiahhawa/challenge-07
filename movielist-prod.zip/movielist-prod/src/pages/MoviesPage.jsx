import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { XIcon } from "lucide-react";
import Navigation from "../components/layout/Navigation";
import SearchInput from "../components/SearchInput";
import MovieCard from "../components/MovieCard";
import notFound from "../assets/not-found.svg";
import { getGenres, getMovies } from "../store/actions/movieActions";

export default function MoviesPage() {
  // menggunakan hook useSearchParams dari react-router untuk mendapatkan query parameter dari URL
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState(() => searchParams.get("query") || "");

  const dispatch = useDispatch();
  const { movies, genres } = useSelector((state) => state.movie);

  const onSearchChange = (event) => {
    setSearch(event.target.value);
  };

  const handleFilters = (event) => {
    if (!event.target.value) {
      // menghapus query parameter berdasarkan id dari elemen input jika value kosong
      searchParams.delete(event.target.id);
    } else {
      // mengubah query parameter berdasarkan id dari elemen input sebagai kunci dan value sebagai isinya
      searchParams.set(event.target.id, event.target.value);
    }
    // mengubah query parameter menjadi state terbaru dari searchParams
    setSearchParams(searchParams);
  };

  // handler submit form pencarian
  const handleSearch = (event) => {
    event.preventDefault();
    if (!search || search.trim() === "") {
      alert("Search input must be filled!");
      return;
    }

    searchParams.set("query", search);
    setSearchParams(searchParams);
  };

  // handler menghapus semua filter
  const handleClear = () => {
    setSearch("");
    setSearchParams({});
  };

  useEffect(() => {
    dispatch(getGenres());
  }, [dispatch]);

  // efek yang akan berjalan setiap searchParams berubah, mengambil data movie baru dari API sesuai searchParams
  useEffect(() => {
    // dispatch pencarian movie sesuai dengan semua filter yang ada
    dispatch(getMovies(searchParams));
  }, [dispatch, searchParams]);

  return (
    <>
      <Navigation />
      <main className="container mx-auto mt-4 space-y-4">
        <h1 className="text-3xl font-semibold">Movies</h1>
        <form onSubmit={handleSearch} className="flex flex-wrap items-center gap-4">
          <fieldset>
            <label htmlFor="search" className="block mb-2 text-sm font-medium text-black">
              Search
            </label>
            <SearchInput value={search} onChange={onSearchChange} />
          </fieldset>

          <fieldset>
            <label htmlFor="with_genres" className="block mb-2 text-sm font-medium text-black">
              Genre
            </label>
            <select
              id="with_genres"
              className="bg-white border-2 border-cyan-500 rounded-full px-2 py-1"
              onChange={handleFilters}
              // menggunakan defaultValue untuk memberikan nilai default dari select sesuai query parameter atau kosong
              defaultValue={searchParams.get("with_genres") || ""}
            >
              <option value="">All</option>
              {/* menampilkan option genre dari state genres */}
              {genres.map((genre) => (
                <option key={genre.id} value={genre.id}>
                  {genre.name}
                </option>
              ))}
            </select>
          </fieldset>

          <fieldset>
            <label htmlFor="page" className="block mb-2 text-sm font-medium text-black">
              Page
            </label>
            <select
              id="page"
              onChange={handleFilters}
              className="bg-white border-2 border-cyan-500 rounded-full px-2 py-1"
              defaultValue={searchParams.get("page") || "1"}
            >
              <option value="1">1</option>
              <option value="2">2</option>
              <option value="3">3</option>
            </select>
          </fieldset>

          <fieldset>
            <label htmlFor="year" className="block mb-2 text-sm font-medium text-black">
              Year
            </label>
            <select
              id="year"
              onChange={handleFilters}
              className="bg-white border-2 border-cyan-500 rounded-full px-2 py-1"
              defaultValue={searchParams.get("year") || ""}
            >
              <option value={""}>All</option>
              <option value="2021">1900 - 2021</option>
              <option value="2022">1900 - 2022</option>
              <option value="2023">1900 - 2023</option>
            </select>
          </fieldset>

          {/* jika ada filter yang dipilih, tampilkan tombol clear filters */}
          {searchParams.size > 0 && (
            <button
              type="button"
              onClick={handleClear}
              className="self-end inline-flex items-center text-cyan-500 hover:underline px-2 py-1"
            >
              <XIcon className="size-5 mr-2" />
              Clear Filters
            </button>
          )}
        </form>

        <section className="space-y-4">
          {/* jika query parameter query ada, tampilkan judul search results, jika tidak tampilkan all movies */}
          {searchParams.get("query") ? (
            <h2 className="text-lg font-medium">
              Search results for &quot;{searchParams.get("query")}&quot;
            </h2>
          ) : (
            <h2 className="text-lg font-medium">All Movies</h2>
          )}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 justify-center gap-8 pb-2">
            {movies.length > 0 ? (
              // jika movies tidak kosong, tampilkan komponen MovieCard untuk setiap movie
              movies.map((movie) => <MovieCard key={movie.id} {...movie} />)
            ) : (
              // jika movies kosong, tampilkan not found
              <div className="col-span-full flex flex-col items-center">
                <img src={notFound} alt="Not Found" role="presentation" className="size-72" />
                <h2 className="text-lg">No movies found!</h2>
              </div>
            )}
          </div>
        </section>
      </main>
    </>
  );
}
