import { Link } from "react-router-dom";
import { useState } from "react";
import { EyeOffIcon, EyeIcon } from "lucide-react";
import GoogleLoginButton from "../components/auth/GoogleLoginButton";
import { useDispatch } from "react-redux";
import { login } from "../store/actions/authActions";

export default function LoginPage() {
  const dispatch = useDispatch();

  const [passwordShown, setPasswordShown] = useState(false);

  // fungsi untuk menampilkan dan menyembunyikan password
  const onShowClick = () => {
    setPasswordShown((prev) => !prev);
  };

  // fungsi handler submit untuk form login
  const onLoginSubmit = (event) => {
    event.preventDefault();
    // mengambil data email dan password dari form
    const { email, password } = Object.fromEntries(new FormData(event.target));
    // mendispatch aksi login
    dispatch(login({ email, password }));
  };

  return (
    <main className="flex w-full h-full min-h-screen flex-col justify-center px-6 py-12 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-sm">
        <h1 className="text-3xl font-extrabold text-cyan-500 text-center">Movie List</h1>
        <h2 className="mt-5 text-center text-xl font-bold leading-9 tracking-tight text-gray-900">
          Log into an existing account
        </h2>
      </div>

      <div className="mt-10 sm:mx-auto sm:w-full sm:max-w-sm">
        <form className="space-y-6" onSubmit={onLoginSubmit}>
          <fieldset>
            <label htmlFor="email" className="block text-sm font-medium leading-6 text-gray-900">
              Email
            </label>
            <div className="mt-2">
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                required
                className="block w-full rounded-md border-0 px-2 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-cyan-600 sm:text-sm sm:leading-6"
              />
            </div>
          </fieldset>

          <fieldset>
            <div className="flex items-center justify-between">
              <label
                htmlFor="password"
                className="block text-sm font-medium leading-6 text-gray-900"
              >
                Password
              </label>
            </div>
            <div className="mt-2 relative">
              <input
                id="password"
                name="password"
                type={passwordShown ? "text" : "password"}
                autoComplete="current-password"
                required
                className="block w-full rounded-md border-0 px-2 py-1.5 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 placeholder:text-gray-400 focus:ring-2 focus:ring-inset focus:ring-cyan-600 sm:text-sm sm:leading-6"
              />
              <div className="absolute h-full flex items-center top-0 right-1">
                <button
                  className="px-2 py-1 text-sm shadow-sm bg-white hover:bg-zinc-100 text-gray-900 hover:text-cyan-500 ring-1 ring-inset ring-gray-300 rounded-md"
                  id="show-password"
                  type="button"
                  onClick={onShowClick}
                >
                  {passwordShown ? (
                    <EyeOffIcon className="size-5" />
                  ) : (
                    <EyeIcon className="size-5" />
                  )}
                  <span className="sr-only">Show password</span>
                </button>
              </div>
            </div>
          </fieldset>

          <div className="flex flex-col w-full gap-2">
            <button
              type="submit"
              className="flex w-full justify-center rounded-md bg-cyan-500 px-3 py-1.5 text-sm font-semibold leading-6 text-white shadow-sm hover:bg-cyan-600 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-cyan-600"
            >
              Sign in
            </button>
            <GoogleLoginButton />
          </div>
        </form>

        <p className="mt-10 text-center text-sm text-gray-500">
          Don&apos;t have an account yet?{" "}
          <Link
            to="/register"
            className="font-semibold leading-6 text-cyan-500 hover:text-cyan-600"
          >
            Register here!
          </Link>
        </p>
      </div>
    </main>
  );
}
