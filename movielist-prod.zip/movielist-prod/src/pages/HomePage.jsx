import { useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowRightIcon } from "lucide-react";
import BannerSlider from "../components/slider/BannerSlider";
import Navigation from "../components/layout/Navigation";
import MovieCard from "../components/MovieCard";
import { useSelector } from "react-redux";
import { useDispatch } from "react-redux";
import { getMovies } from "../store/actions/movieActions";
import { getTopRatedMovies } from "../store/actions/movieActions";

export default function HomePage() {
  const rated = useSelector((state) => state.movie.rated);
  console.log(rated);
  const { movies } = useSelector((state) => state.movie);
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(getMovies());
  }, [dispatch]);

  useEffect(() => {
    dispatch(getTopRatedMovies());
  }, []);

  return (
    <main className="w-full h-full min-h-screen">
      {/* section page untuk banner / hero */}
      <section id="banner">
        <Navigation variant="banner" />
        <BannerSlider />
      </section>

      {/* section page untuk movie populer */}
      <section id="popular" className="container space-y-4 px-5 mx-auto my-10">
        <div className="w-full flex flex-wrap justify-between">
          <h2 className="text-3xl font-semibold">Popular Movies</h2>
          {/*  link menuju halaman movies */}
          <Link
            to="/movies"
            className="inline-flex font-medium text-cyan-500 hover:underline items-center"
          >
            See All Movies
            <ArrowRightIcon className="ml-2 size-5 text-cyan-500" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 justify-center gap-8 pb-2">
          {movies.map((movie) => (
            // merender komponen MovieCard untuk setiap movie
            <MovieCard key={movie.id} {...movie} />
          ))}
        </div>
      </section>

      {/* section page untuk top rated */}
      <section id="rated" className="container space-y-4 px-5 mx-auto my-10">
        <div className="w-full flex flex-wrap justify-between">
          <h2 className="text-3xl font-semibold">Top Rated Movies</h2>
          {/*  link menuju halaman movies */}
          <Link
            to="/rated"
            className="inline-flex font-medium text-cyan-500 hover:underline items-center"
          >
            See All Movies
            <ArrowRightIcon className="ml-2 size-5 text-cyan-500" />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 justify-center gap-8 pb-2">
          {rated.map((movie) => (
            // merender komponen MovieCard untuk setiap movie
            <MovieCard key={movie.id} {...movie} />
          ))}
        </div>
      </section>
    </main>
  );
}
