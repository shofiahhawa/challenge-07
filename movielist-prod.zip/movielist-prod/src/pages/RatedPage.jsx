import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { XIcon } from "lucide-react";
import Navigation from "../components/layout/Navigation";
import SearchInput from "../components/SearchInput";
import MovieCard from "../components/MovieCard";
import notFound from "../assets/not-found.svg";
import { getGenres, getMovies, getTopRatedMovies } from "../store/actions/movieActions";

export default function RatedPage() {
  // menggunakan hook useSearchParams dari react-router untuk mendapatkan query parameter dari URL
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState(() => searchParams.get("query") || "");

  const dispatch = useDispatch();
  const { rated, genres } = useSelector((state) => state.movie);

  const data = useSelector((state) => state.movie.pagination);
  // handler submit form pencarian
  const handleSearch = (event) => {
    event.preventDefault();
    if (!search || search.trim() === "") {
      alert("Search input must be filled!");
      return;
    }

    searchParams.set("query", search);
    setSearchParams(searchParams);
  };

  useEffect(() => {
    dispatch(getGenres());
  }, [dispatch]);

  // efek yang akan berjalan setiap searchParams berubah, mengambil data movie baru dari API sesuai searchParams
  useEffect(() => {
    // dispatch pencarian movie sesuai dengan semua filter yang ada
    dispatch(getTopRatedMovies(currentPage));
  }, [dispatch]);

  // pagination
  let [currentPage, setCurrentPage] = useState(1);
  const totalPages = useSelector((state) => state?.movie?.pagination?.total_pages) || 1;
  console.log("totalPages", totalPages);

  const setNextPage = () => {
    setCurrentPage((currentPage += 1));
    dispatch(getTopRatedMovies(currentPage));
  };

  const setPreviousPage = () => {
    setCurrentPage((currentPage -= 1));
    dispatch(getTopRatedMovies(currentPage));
  };
  useEffect(() => {
    dispatch(getTopRatedMovies(currentPage));
  }, [dispatch, currentPage]);

  return (
    <>
      <Navigation />
      <main className="container mx-auto mt-4 space-y-4">
        <h1 className="text-3xl font-semibold">Movies</h1>

        <section className="space-y-4">
          {/* jika query parameter query ada, tampilkan judul search results, jika tidak tampilkan all movies */}

          {searchParams.get("query") ? (
            <h2 className="text-lg font-medium">
              Search results for &quot;{searchParams.get("query")}&quot;
            </h2>
          ) : (
            <h2 className="text-lg font-medium">All Movies</h2>
          )}
          <div className="flex justify-center mt-4">
            <button
              disabled={currentPage === 1}
              onClick={() => setPreviousPage()}
              className="mr-2 px-4 py-2 bg-gray-200 rounded-md"
            >
              Previous
            </button>
            <span className="mx-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setNextPage()}
              disabled={currentPage === totalPages}
              className="ml-2 px-4 py-2 bg-gray-200 rounded-md"
            >
              Next
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 justify-center gap-8 pb-2">
            {rated.length > 0 ? (
              // jika movies tidak kosong, tampilkan komponen MovieCard untuk setiap movie
              rated.map((movie) => <MovieCard key={movie.id} {...movie} />)
            ) : (
              // jika movies kosong, tampilkan not found
              <div className="col-span-full flex flex-col items-center">
                <img src={notFound} alt="Not Found" role="presentation" className="size-72" />
                <h2 className="text-lg">No movies found!</h2>
              </div>
            )}
          </div>
        </section>
      </main>
    </>
  );
}
